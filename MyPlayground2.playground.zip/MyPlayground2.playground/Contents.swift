import UIKit

var greeting = "Hello, playground"

//Tuples:1

var httpError = (errorCode : 404 , errorMessage : "page Not Found")
print(httpError)
print(httpError.errorCode , terminator : ":")
print(httpError.errorMessage)

//2
var name = ("John","Smith")
var fName = name.0
var lName = name.1
print(fName , terminator : ",")
print(lName)

//3
var origin = (x:0 , y:0)
var point = origin
print(point)

//4
let city = (name : "Maryville" , population : 11,000)
let ( cityName , cityPopulation ) = (city.0 , city.1)
print(cityName)
print(cityPopulation)

//5
let groceries = ("bread","onions")
print(groceries.0)
print(groceries.1)
print(type(of: groceries))

//6
var fname = "joe"
var lname = "Root"
(fname,lname) = (lname ,fname)
