import UIKit

var greeting = "Hello, playground"
print("Hello, All!😍")

var x = 10

//var,let,print stmts,data types
var programmingLanguage = "Swift"
print("My favourite programming language is \(programmingLanguage)")

//3.
var age = 23
print("you are \(age) years old and in another \(age)years,you will be \(age * 2)")

//4
print("""
Hello
world!
""")

//5
print ("Hello All,\rWelcome to swift programming")
//6
let welcomeMessage : String = "Hello!"
print(welcomeMessage , "All")
//7
print("The list of numbers are ")
print(1,2,3,4,5,6)
print("The new pattern is")
print(1,2,3,4,5,6,separator: "-")
//8
print("Fall 2021")



//lab:2
//1
let pi = 3.14
print(pi)
//pi = 3.13

//2.
var aweMessage = "This is Superb!"
print(aweMessage)
print("AweMessage")

//3
var course1 = "ios"
var course2 = "java"
print(course1,course2)
print(course1,"-",course2)

//4
print(10,20,30)
print(12.5,15.5)

//5
var years : Int = 23
years = years * 2
print(years)
//6
var mobilebrand = "Apple"
mobilebrand = "Samsung"
print(mobilebrand)
